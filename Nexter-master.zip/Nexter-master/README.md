# Course: [Advanced CSS and SASS ](https://www.udemy.com/advanced-css-and-sass/)
## Author: Jonas Schmedtmann
## Student: Alan Fidelino
##### [See the live demo ](https://afide26.github.io/Nexter/)
---

## Tools used in this course:
1. CSS and SASS
2. BEM (Block Element Modifier)
3. Transitions
4. Use of CSS Color variables
5. Color-gradients
6. CSS Grids
7. Background Images, Background Videos and more....


---
##### [Learn this course from UDEMY ](https://www.udemy.com/advanced-css-and-sass/)